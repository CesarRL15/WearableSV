package com.example.signosvitalessp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class menuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);
    }
}